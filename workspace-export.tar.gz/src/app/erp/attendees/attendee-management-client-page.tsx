'use client';

import React, { useState, useMemo, useTransition, useEffect } from 'react';
import type { TrainingSchedule, Course, CourseCategory, AttendeeData, TrainingRecord, RegistrationFormField, AttendeeStatus, AttendeeAttendanceStatus } from '@/lib/course-data';
import Image from 'next/image';
import { format, parseISO } from 'date-fns';
import { th } from 'date-fns/locale';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { MoreHorizontal, Clock, BookCheck, ShieldCheck, XCircle, UserRound, UserRoundX, CalendarClock, Loader2, PlusCircle, Filter, Building } from 'lucide-react';
import { useAuth } from '@/context/auth-context';
import { useFirestore, useCollection, useMemoFirebase, updateDocumentNonBlocking } from '@/firebase';
import { collection, query, where, doc, getDocs, documentId } from 'firebase/firestore';
import { cn } from '@/lib/utils';
import { CourseFilters } from '@/components/erp/course-filters';
import { updateTrainingRecord } from './actions';

type StatusFilter = 'all' | 'pending' | 'verified';

const attendeeStatusConfig: Record<AttendeeStatus, { label: string; icon: React.ElementType; className: string }> = {
    pending_verification: { label: 'รอตรวจเอกสาร', icon: Clock, className: 'bg-amber-500 hover:bg-amber-600' },
    docs_verified: { label: 'เอกสารครบถ้วน', icon: BookCheck, className: 'bg-blue-600 hover:bg-blue-700' },
    completed: { label: 'ผ่านการอบรม', icon: ShieldCheck, className: 'bg-green-600 hover:bg-green-700' },
    failed: { label: 'ไม่ผ่านการอบรม', icon: XCircle, className: 'bg-red-600 hover:bg-red-700'}
};

const attendanceStatusConfig: Record<AttendeeAttendanceStatus, { label: string; icon: React.ElementType; className: string }> = {
    present: { label: 'มาเรียน', icon: UserRound, className: 'bg-green-100 text-green-800' },
    absent: { label: 'ขาดเรียน', icon: UserRoundX, className: 'bg-red-100 text-red-800' },
    not_checked_in: { label: 'ยังไม่เช็คชื่อ', icon: CalendarClock, className: 'bg-gray-100 text-gray-800' },
};

function VerificationStatusBadge({ status }: { status: AttendeeStatus }) {
    const config = attendeeStatusConfig[status] || attendeeStatusConfig.pending_verification;
    return (
        <Badge className={cn('text-white whitespace-nowrap px-2 py-0.5 font-semibold', config.className)}>
            <config.icon className="w-3 h-3 mr-1.5" />
            {config.label}
        </Badge>
    );
}

function AttendanceStatusBadge({ status }: { status: AttendeeAttendanceStatus }) {
    const config = attendanceStatusConfig[status] || attendanceStatusConfig.not_checked_in;
    return <Badge variant="secondary" className={cn('font-semibold', config.className)}>{config.label}</Badge>;
}

function InlineScoreEditor({ recordId, initialScores }: { recordId: string, initialScores: {pre: string, post: string} }) {
    const firestore = useFirestore();
    const [preTestScore, setPreTestScore] = useState(initialScores.pre || '');
    const [postTestScore, setPostTestScore] = useState(initialScores.post || '');

    const handleScoreChange = () => {
         if (preTestScore === (initialScores.pre || '') && postTestScore === (initialScores.post || '')) return;
         const recordRef = doc(firestore, 'trainingRecords', recordId);
         updateDocumentNonBlocking(recordRef, { preTestScore, postTestScore });
    }

     return (
        <div className="flex items-center gap-2">
            <Input value={preTestScore} onChange={e => setPreTestScore(e.target.value)} onBlur={handleScoreChange} className="h-8 text-sm w-16 text-center rounded-lg" placeholder="-" />
            <Input value={postTestScore} onChange={e => setPostTestScore(e.target.value)} onBlur={handleScoreChange} className="h-8 text-sm w-16 text-center rounded-lg" placeholder="-" />
        </div>
    );
}

export function AttendeeManagementClientPage({ schedules, courses, categories }: { schedules: TrainingSchedule[], courses: Course[], categories: CourseCategory[] }) {
    const { profile } = useAuth();
    const firestore = useFirestore();
    
    const [categoryFilter, setCategoryFilter] = useState<string>('all');
    const [courseFilter, setCourseFilter] = useState<string>('all');
    const [scheduleFilter, setScheduleFilter] = useState<string>('all');
    const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
    const [searchQuery, setSearchQuery] = useState('');
    
    const recordsQuery = useMemoFirebase(() => {
        if (scheduleFilter === 'all' || !firestore) return null;
        let conditions = [where('scheduleId', '==', scheduleFilter)];
        if (statusFilter === 'pending') conditions.push(where('status', '==', 'pending_verification'));
        else if (statusFilter === 'verified') conditions.push(where('status', 'in', ['docs_verified', 'completed', 'failed']));
        return query(collection(firestore, 'trainingRecords'), ...conditions);
    }, [scheduleFilter, statusFilter, firestore]);

    const { data: records = [], isLoading } = useCollection<TrainingRecord>(recordsQuery);

    const filteredRecords = useMemo(() => {
        if (!searchQuery) return records;
        const searchLower = searchQuery.toLowerCase();
        return records.filter(r => 
            r.attendeeName.toLowerCase().includes(searchLower) || 
            r.companyName.toLowerCase().includes(searchLower)
        );
    }, [records, searchQuery]);

    const selectedScheduleDetails = useMemo(() => {
        if (scheduleFilter === 'all') return null;
        const schedule = schedules.find(s => s.id === scheduleFilter);
        const course = courses.find(c => c.id === schedule?.courseId);
        return { ...schedule, courseTitle: course?.shortName || schedule?.courseTitle };
    }, [scheduleFilter, schedules, courses]);

    return (
        <div className="space-y-6">
            <Card className="border-none shadow-lg rounded-[2rem] overflow-hidden bg-white dark:bg-slate-950">
                <CardHeader className="bg-muted/30 border-b pb-8">
                    <CourseFilters 
                        courses={courses}
                        categories={categories}
                        schedules={schedules}
                        searchQuery={searchQuery}
                        onSearchChange={setSearchQuery}
                        categoryFilter={categoryFilter}
                        onCategoryChange={(v) => {setCategoryFilter(v); setCourseFilter('all'); setScheduleFilter('all');}}
                        courseFilter={courseFilter}
                        onCourseChange={(v) => {setCourseFilter(v); setScheduleFilter('all');}}
                        scheduleFilter={scheduleFilter}
                        onScheduleChange={setScheduleFilter}
                    />
                </CardHeader>
            </Card>

            {scheduleFilter !== 'all' && (
                 <Card className="border-none shadow-xl rounded-[2rem] overflow-hidden bg-white dark:bg-slate-950">
                    <CardHeader className="p-8 pb-6 text-left">
                        <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                            <div className="space-y-2">
                                <CardTitle className="text-2xl font-bold font-headline">{selectedScheduleDetails?.courseTitle}</CardTitle>
                                <div className="flex flex-wrap items-center gap-2">
                                    <Badge variant="secondary" className="bg-blue-50 text-blue-700 font-bold px-3 py-1 rounded-lg">
                                        <Users className="h-3.5 w-3.5 mr-1.5"/> {records.length} คน
                                    </Badge>
                                    <Badge variant="secondary" className="bg-slate-50 text-slate-700 font-bold px-3 py-1 rounded-lg">
                                        <Building className="h-3.5 w-3.5 mr-1.5"/> {new Set(records.map(a => a.companyName)).size} บริษัท
                                    </Badge>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="space-y-1">
                                    <Label className="text-[10px] uppercase tracking-widest font-bold text-slate-400 ml-2">ตัวกรองสถานะ</Label>
                                    <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
                                        <SelectTrigger className="w-[180px] h-11 rounded-xl bg-slate-50 dark:bg-slate-900 border-none font-semibold">
                                            <SelectValue placeholder="กรองสถานะ" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">ทั้งหมด</SelectItem>
                                            <SelectItem value="pending">รอตรวจสอบ</SelectItem>
                                            <SelectItem value="verified">ตรวจสอบแล้ว</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="p-0">
                         <div className="overflow-x-auto">
                            <Table className="min-w-[1000px]">
                                <TableHeader className="bg-slate-50/50 dark:bg-slate-900/30 border-y">
                                    <TableRow className="hover:bg-transparent">
                                        <TableHead className="py-5 pl-8 uppercase tracking-widest text-[10px] text-slate-400 font-bold">ผู้อบรม / บริษัท</TableHead>
                                        <TableHead className="uppercase tracking-widest text-[10px] text-slate-400 font-bold">การเข้าเรียน</TableHead>
                                        <TableHead className="uppercase tracking-widest text-[10px] text-slate-400 font-bold">การตรวจสอบ</TableHead>
                                        <TableHead className="uppercase tracking-widest text-[10px] text-slate-400 font-bold">คะแนน (Pre/Post)</TableHead>
                                        <TableHead className="text-right pr-8 uppercase tracking-widest text-[10px] text-slate-400 font-bold">Actions</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {isLoading ? (
                                        <TableRow><TableCell colSpan={5} className="h-48 text-center"><Loader2 className="h-8 w-8 animate-spin mx-auto opacity-50"/></TableCell></TableRow>
                                    ) : filteredRecords.length > 0 ? filteredRecords.map((record) => (
                                        <TableRow key={record.id} className="hover:bg-muted/5 transition-colors">
                                            <TableCell className="py-6 pl-8 text-left font-bold">{record.attendeeName}<div className="text-[10px] text-muted-foreground font-medium uppercase mt-1">{record.companyName}</div></TableCell>
                                            <TableCell className="text-left"><AttendanceStatusBadge status={record.attendance} /></TableCell>
                                            <TableCell className="text-left"><VerificationStatusBadge status={record.status} /></TableCell>
                                            <TableCell><InlineScoreEditor recordId={record.id} initialScores={{ pre: record.preTestScore || '', post: record.postTestScore || '' }}/></TableCell>
                                            <TableCell className="text-right pr-8"><Button variant="outline" size="sm" className="rounded-lg h-9 font-bold border-slate-200">จัดการ</Button></TableCell>
                                        </TableRow>
                                    )) : (
                                        <TableRow><TableCell colSpan={5} className="h-48 text-center italic opacity-50">ไม่พบข้อมูลผู้อบรม</TableCell></TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}