'use client';

import React, { useState, useMemo, useTransition, useEffect } from 'react';
import type { Registration, Course, RegistrationStatus, CourseCategory, TrainingSchedule, IndividualAttendeeStatus, RegistrationFormField, RegistrationAttendee } from '@/lib/course-data';
import Link from 'next/link';
import { format } from 'date-fns';
import { th } from 'date-fns/locale';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { 
    MoreHorizontal, 
    Trash2, 
    Loader2, 
    CheckCircle, 
    Clock, 
    XCircle, 
    Edit, 
    Users, 
    UserCheck, 
    CalendarPlus, 
    Building, 
    Calendar, 
    FileText, 
    FileSignature, 
    Filter, 
    ExternalLink, 
    GraduationCap, 
    Info, 
    MapPin, 
    CreditCard,
    Printer,
    History,
    AlertTriangle,
    DatabaseZap,
    User
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { 
    updateIndividualAttendeeStatus, 
    deleteRegistration, 
    createQuotationAction, 
    createInvoiceAction, 
    rescheduleRegistrationAction,
    rescheduleIndividualAttendeesAction
} from './actions';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, where, orderBy } from 'firebase/firestore';
import { cn } from '@/lib/utils';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDebounce } from '@/hooks/use-debounce';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { CourseFilters } from '@/components/erp/course-filters';

const attendeeStatusConfig: Record<IndividualAttendeeStatus, { label: string; icon: React.ElementType; badgeClass: string; }> = {
  pending: { label: 'รออนุมัติ', icon: Clock, badgeClass: 'bg-amber-100 text-amber-800 border-amber-200' },
  confirmed: { label: 'ยืนยันแล้ว', icon: CheckCircle, badgeClass: 'bg-green-100 text-green-800 border-green-200' },
  postponed: { label: 'เลื่อนรอบ', icon: CalendarPlus, badgeClass: 'bg-blue-100 text-blue-800 border-blue-200' },
  cancelled: { label: 'ยกเลิก', icon: XCircle, badgeClass: 'bg-red-100 text-red-800 border-red-200' },
};

function AttendeeStatusBadge({ status }: { status: IndividualAttendeeStatus }) {
  const config = attendeeStatusConfig[status] || attendeeStatusConfig.pending;
  return (
    <Badge variant="outline" className={cn('gap-x-1.5 whitespace-nowrap px-2 py-0.5 font-semibold', config.badgeClass)}>
      <config.icon className="h-3.5 w-3.5" />
      {config.label}
    </Badge>
  );
}

function RescheduleDialog({ 
    registration, 
    attendeeIds,
    schedules, 
    isOpen, 
    onClose, 
    onSuccess 
}: { 
    registration: Registration | null, 
    attendeeIds?: string[], 
    schedules: TrainingSchedule[], 
    isOpen: boolean, 
    onClose: () => void, 
    onSuccess: () => void 
}) {
    const { toast } = useToast();
    const [isPending, startTransition] = useTransition();
    const [selectedScheduleId, setSelectedScheduleId] = useState<string>('');

    const availableSchedules = useMemo(() => {
        if (!registration) return [];
        return schedules.filter(s => s.courseId === registration.courseId && s.id !== registration.scheduleId);
    }, [registration, schedules]);

    const handleConfirm = () => {
        if (!registration || !selectedScheduleId) return;
        startTransition(async () => {
            let result;
            if (attendeeIds && attendeeIds.length > 0) {
                result = await rescheduleIndividualAttendeesAction({
                    registrationId: registration.id,
                    attendeeIds,
                    newScheduleId: selectedScheduleId
                });
            } else {
                result = await rescheduleRegistrationAction(registration.id, selectedScheduleId);
            }

            if (result.success) {
                toast({ title: 'สำเร็จ!', description: result.message });
                onSuccess();
                onClose();
            } else {
                toast({ variant: 'destructive', title: 'เกิดข้อผิดพลาด', description: result.message });
            }
        });
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-md rounded-[2rem] z-[200]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 font-bold">
                        <History className="text-primary"/> เลื่อนรอบการอบรม
                    </DialogTitle>
                    <DialogDescription>
                        {attendeeIds && attendeeIds.length > 0 
                            ? `ย้ายผู้อบรมที่เลือกจำนวน ${attendeeIds.length} ท่านไปยังรอบใหม่`
                            : `เลือกปี/เดือน/รอบ ที่ต้องการย้ายใบสมัครของ ${registration?.clientCompanyName || 'ผู้อบรมท่านนี้'} ไป`
                        }
                    </DialogDescription>
                </DialogHeader>
                <div className="py-6 space-y-4">
                    <Label className="font-semibold">เลือกรอบอบรมใหม่ (เฉพาะหลักสูตรเดียวกัน)</Label>
                    <Select value={selectedScheduleId} onValueChange={setSelectedScheduleId}>
                        <SelectTrigger className="h-12 rounded-xl">
                            <SelectValue placeholder="ค้นหารอบอบรมที่เปิดอยู่..." />
                        </SelectTrigger>
                        <SelectContent className="z-[210]">
                            {availableSchedules.length > 0 ? availableSchedules.map(s => (
                                <SelectItem key={s.id} value={s.id}>
                                    {format(new Date(s.startDate), 'd MMM yy', {locale: th})} - {s.location}
                                </SelectItem>
                            )) : (
                                <div className="p-4 text-center text-xs text-muted-foreground">ไม่พบรอบอบรมอื่นที่เปิดอยู่</div>
                            )}
                        </SelectContent>
                    </Select>
                </div>
                <DialogFooter className="gap-2">
                    <Button variant="ghost" onClick={onClose} className="rounded-xl">ยกเลิก</Button>
                    <Button onClick={handleConfirm} disabled={!selectedScheduleId || isPending} className="rounded-xl font-bold h-11 px-6">
                        {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                        ยืนยันการย้ายรอบ
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function RegistrationDetailsDialog({ registration, isOpen, onClose }: { registration: Registration | null, isOpen: boolean, onClose: () => void }) {
    if (!registration) return null;

    const renderFieldValue = (field: RegistrationFormField) => {
        const value = registration.formData[field.id];
        if (!value && field.type !== 'header' && field.type !== 'page_break') return null;

        switch (field.type) {
            case 'header':
                return (
                    <div className="mt-8 mb-4 border-l-4 border-primary pl-4" key={field.id}>
                        <h4 className="text-lg font-bold text-slate-900 dark:text-white">{field.label}</h4>
                        {field.description && <p className="text-xs text-muted-foreground mt-1 font-light">{field.description}</p>}
                    </div>
                );
            case 'coordinator':
                return (
                    <div key={field.id} className="grid grid-cols-1 sm:grid-cols-3 gap-6 bg-slate-50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-inner">
                        <div className="text-left"><Label className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">ผู้ประสานงาน</Label><p className="font-semibold text-sm mt-1">{value?.name || '-'}</p></div>
                        <div className="text-left"><Label className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">เบอร์โทร</Label><p className="font-semibold text-sm mt-1">{value?.tel || '-'}</p></div>
                        <div className="text-left"><Label className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">อีเมล</Label><p className="font-semibold text-sm mt-1 break-all">{value?.email || '-'}</p></div>
                    </div>
                );
            case 'address':
                const billing = value?.billingAddress || {};
                const shipping = value?.isShippingSameAsBilling ? billing : (value?.shippingAddress || {});
                return (
                    <div key={field.id} className="grid md:grid-cols-2 gap-6 mt-4 text-left">
                        <div className="space-y-3">
                            <Label className="font-bold text-[10px] uppercase tracking-[0.2em] text-blue-600 flex items-center gap-2">
                                <CreditCard className="w-3.5 h-3.5"/> ที่อยู่ออกใบกำกับภาษี
                            </Label>
                            <div className="text-sm bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm leading-relaxed">
                                <p className="font-semibold text-slate-900 dark:text-white">{billing.address1 || '-'}</p>
                                <p className="text-slate-600 dark:text-slate-400 font-light">
                                    {billing.subdistrict ? `ต.${billing.subdistrict} ` : ''} 
                                    {billing.district ? `อ.${billing.district} ` : ''} 
                                    {billing.province ? `จ.${billing.province} ` : ''} 
                                    {billing.postalCode || ''}
                                </p>
                            </div>
                        </div>
                        <div className="space-y-3">
                            <Label className="font-bold text-[10px] uppercase tracking-[0.2em] text-emerald-600 flex items-center gap-2">
                                <MapPin className="w-3.5 h-3.5"/> ที่อยู่จัดส่งวุฒิบัตร
                            </Label>
                            <div className="text-sm bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm leading-relaxed">
                                {value?.isShippingSameAsBilling ? (
                                    <div className="flex flex-col items-center justify-center gap-2 text-muted-foreground italic h-full py-4 opacity-60">
                                        <CheckCircle className="w-6 h-6 text-emerald-500 mb-1"/>
                                        <span className="text-xs">ใช้ที่อยู่เดียวกับใบเสร็จ</span>
                                    </div>
                                ) : (
                                    <>
                                        <p className="font-semibold text-slate-900 dark:text-white">{shipping.address1 || '-'}</p>
                                        <p className="text-slate-600 dark:text-slate-400 font-light">
                                            {shipping.subdistrict ? `ต.${shipping.subdistrict} ` : ''} 
                                            {shipping.district ? `อ.${shipping.district} ` : ''} 
                                            {shipping.province ? `จ.${shipping.province} ` : ''} 
                                            {shipping.postalCode || ''}
                                        </p>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>
                );
            case 'attendee_list':
                return (
                    <div className="space-y-4 mt-6 text-left" key={field.id}>
                        <Label className="font-bold text-[10px] uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                            <Users className="w-3.5 h-3.5"/> รายชื่อผู้อบรม ({value?.length || 0} ท่าน)
                        </Label>
                        <div className="rounded-2xl border border-slate-100 dark:border-slate-800 overflow-hidden shadow-sm bg-white dark:bg-slate-950">
                            <Table>
                                <TableBody>
                                    {value?.map((att: any, idx: number) => (
                                        <TableRow key={att.id} className="hover:bg-slate-50/50 transition-colors border-b last:border-none">
                                            <TableCell className="py-4 px-6 font-semibold text-sm text-slate-700 dark:text-slate-300">
                                                <span className="text-slate-300 mr-3 font-mono">{String(idx + 1).padStart(2, '0')}</span>
                                                {att.fullName || 'ผู้อบรม'}
                                            </TableCell>
                                            <TableCell className="py-4 px-6 text-right">
                                                <AttendeeStatusBadge status={att.status}/>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                );
            default:
                return (
                    <div className="py-3 border-b border-slate-50 dark:border-slate-900 last:border-none text-left" key={field.id}>
                        <Label className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">{field.label}</Label>
                        <p className="font-semibold text-sm text-slate-800 dark:text-slate-200 mt-1">{String(value || '-')}</p>
                    </div>
                );
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={(v) => !v && onClose()}>
            <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col p-0 overflow-hidden rounded-[2rem] border-none shadow-2xl">
                <DialogHeader className="p-10 pb-8 border-b bg-white dark:bg-slate-950 text-left">
                    <DialogTitle className="text-2xl font-bold font-headline">ข้อมูลใบสมัคร</DialogTitle>
                    <DialogDescription>ID: {registration.id}</DialogDescription>
                </DialogHeader>
                <div className="flex-1 overflow-y-auto px-10 py-8 custom-scrollbar space-y-6">
                    {registration.formSchema.map(renderFieldValue)}
                </div>
                <DialogFooter className="p-8 border-t bg-white dark:bg-slate-950">
                    <Button variant="ghost" onClick={onClose} className="rounded-xl font-bold h-12">ปิด</Button>
                    <Button asChild className="rounded-xl font-bold h-12 shadow-lg">
                        <Link href={`/erp/registrations/edit/${registration.id}`}><Edit className="w-4 h-4 mr-2"/> แก้ไขข้อมูล</Link>
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function ManageAttendeesDialog({
  registration: initialRegistration,
  isOpen,
  onClose,
  onStateSave,
  onRescheduleClick
}: {
  registration: Registration | null,
  isOpen: boolean,
  onClose: () => void,
  onStateSave: () => void,
  onRescheduleClick: (attendeeIds: string[]) => void
}) {
  const { toast } = useToast();
  const [isActionPending, startTransition] = useTransition();
  const [selectedAttendeeIds, setSelectedAttendeeIds] = useState<Set<string>>(new Set());

  const attendees = useMemo(() => {
    if (!initialRegistration) return [];
    const attendeeListField = initialRegistration.formSchema.find(f => f.type === 'attendee_list');
    return attendeeListField ? (initialRegistration.formData[attendeeListField.id] || []) as RegistrationAttendee[] : [];
  }, [initialRegistration]);

  const handleUpdateStatus = (attendeeIds: string[], newStatus: IndividualAttendeeStatus) => {
    if (!initialRegistration) return;
    const attendeeListField = initialRegistration.formSchema.find(f => f.type === 'attendee_list');
    if (!attendeeListField) return;

    startTransition(async () => {
      const result = await updateIndividualAttendeeStatus({
        registrationId: initialRegistration.id,
        attendeeListFieldId: attendeeListField.id,
        attendeeIds,
        newStatus,
      });

      if (result.success) {
        toast({ title: 'สำเร็จ!', description: result.message });
        setSelectedAttendeeIds(new Set());
        onStateSave();
      } else {
        toast({ variant: 'destructive', title: 'เกิดข้อผิดพลาด', description: result.message });
      }
    });
  };

  if (!initialRegistration) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col p-0 overflow-hidden rounded-[2rem] border-none shadow-2xl">
        <DialogHeader className="p-8 pb-4 text-left">
          <DialogTitle className="text-2xl font-bold font-headline">จัดการผู้อบรม</DialogTitle>
          <DialogDescription>{initialRegistration.courseTitle}</DialogDescription>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto px-8 pb-8 pt-4 custom-scrollbar">
          <div className="border rounded-2xl overflow-hidden shadow-sm">
            <Table>
              <TableHeader className="bg-slate-50 dark:bg-slate-900/50">
                <TableRow>
                  <TableHead className="w-[50px]"></TableHead>
                  <TableHead className="font-bold">ชื่อ-นามสกุล</TableHead>
                  <TableHead className="font-bold">สถานะ</TableHead>
                  <TableHead className="text-right font-bold">ดำเนินการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attendees.map(attendee => {
                    const fullNameFieldId = initialRegistration.formSchema.find(f => f.type === 'attendee_list')?.subFields?.find(sf => sf.label.includes("ชื่อ-นามสกุล"))?.id;
                    return (
                        <TableRow key={attendee.id}>
                            <TableCell>
                                <Checkbox 
                                    checked={selectedAttendeeIds.has(attendee.id)}
                                    onCheckedChange={(checked) => {
                                        const newSet = new Set(selectedAttendeeIds);
                                        if (checked) newSet.add(attendee.id);
                                        else newSet.delete(attendee.id);
                                        setSelectedAttendeeIds(newSet);
                                    }}
                                />
                            </TableCell>
                            <TableCell className="text-left font-medium">
                                {fullNameFieldId ? attendee[fullNameFieldId] : 'N/A'}
                            </TableCell>
                            <TableCell className="text-left"><AttendeeStatusBadge status={attendee.status} /></TableCell>
                            <TableCell className="text-right">
                                <Button variant="ghost" size="sm" onClick={() => handleUpdateStatus([attendee.id], 'confirmed')} className="text-green-600">ยืนยัน</Button>
                                <Button variant="ghost" size="sm" onClick={() => onRescheduleClick([attendee.id])} className="text-blue-600">เลื่อนรอบ</Button>
                            </TableCell>
                        </TableRow>
                    );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
        <DialogFooter className="p-6 border-t">
            <Button variant="outline" disabled={selectedAttendeeIds.size === 0} onClick={() => handleUpdateStatus(Array.from(selectedAttendeeIds), 'confirmed')}>ยืนยันที่เลือก ({selectedAttendeeIds.size})</Button>
            <Button onClick={onClose}>ปิด</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function RegistrationsClientPage({ courses, categories, schedules }: { courses: Course[], categories: CourseCategory[], schedules: TrainingSchedule[] }) {
    const { toast } = useToast();
    const [isActionPending, startTransition] = useTransition();
    const firestore = useFirestore();

    const [activeTab, setActiveTab] = useState<RegistrationStatus>('pending');
    const [processingId, setProcessingId] = useState<string | null>(null);
    const [indexError, setIndexError] = useState<string | null>(null);

    const [searchQuery, setSearchQuery] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('all');
    const [courseFilter, setCourseFilter] = useState('all');
    const [scheduleFilter, setScheduleFilter] = useState('all');
    const [dateRange, setDateRange] = useState<{from?: Date, to?: Date} | undefined>(undefined);
    const debouncedSearch = useDebounce(searchQuery, 300);

    const [managingRegistration, setManagingRegistration] = useState<Registration | null>(null);
    const [viewingRegistration, setViewingRegistration] = useState<Registration | null>(null);
    const [reschedulingRegistration, setReschedulingRegistration] = useState<Registration | null>(null);
    const [rescheduleAttendeeIds, setRescheduleAttendeeIds] = useState<string[]>([]);
    const [registrationToDelete, setRegistrationToDelete] = useState<Registration | null>(null);

    const coursesMap = useMemo(() => new Map(courses.map(c => [c.id, c])), [courses]);
    const schedulesMap = useMemo(() => new Map(schedules.map(s => [s.id, s])), [schedules]);

    const registrationsQuery = useMemoFirebase(() => {
        if (!firestore) return null;
        let conditions: any[] = [where('status', '==', activeTab)];
        if (courseFilter !== 'all') conditions.push(where('courseId', '==', courseFilter));
        if (scheduleFilter !== 'all') conditions.push(where('scheduleId', '==', scheduleFilter));

        return query(collection(firestore, 'registrations'), ...conditions, orderBy('registrationDate', 'desc'));
    }, [firestore, activeTab, courseFilter, scheduleFilter]);

    const { data: liveRegistrations = [], isLoading, error: queryError } = useCollection<Registration>(registrationsQuery);

    const handleAction = (action: (id: string) => Promise<any>, id: string) => {
        setProcessingId(id);
        startTransition(async () => {
            const result = await action(id);
            if (result.success) toast({ title: 'สำเร็จ!', description: result.message });
            else toast({ variant: 'destructive', title: 'เกิดข้อผิดพลาด', description: result.message });
            setProcessingId(null);
        });
    };

    const filteredRegistrations = useMemo(() => {
        return liveRegistrations.filter(reg => {
            const searchLower = debouncedSearch.toLowerCase();
            const matchesSearch = !debouncedSearch || 
                (reg.clientCompanyName || '').toLowerCase().includes(searchLower) ||
                (reg.userDisplayName || '').toLowerCase().includes(searchLower) ||
                reg.courseTitle.toLowerCase().includes(searchLower);

            let matchesDate = true;
            if (dateRange?.from && dateRange?.to) {
                const regDate = new Date(reg.registrationDate);
                matchesDate = regDate >= dateRange.from && regDate <= dateRange.to;
            }
            return matchesSearch && matchesDate;
        });
    }, [liveRegistrations, debouncedSearch, dateRange]);

    return (
        <div className="space-y-8 pb-20">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 px-4 md:px-0 text-left">
                <div>
                    <h1 className="text-3xl font-bold font-headline tracking-tight text-slate-900 dark:text-white">จัดการข้อมูลการลงทะเบียน</h1>
                    <p className="text-muted-foreground mt-1 font-light">บริหารจัดการข้อมูลผู้อบรมและเอกสารทางการเงินอย่างเป็นระบบแบบ Real-time</p>
                </div>
            </div>

            <Card className="border-none shadow-2xl rounded-[2.5rem] overflow-hidden bg-white dark:bg-slate-950">
                <CardHeader className="bg-slate-50 dark:bg-slate-900/50 border-b pb-10 pt-8 px-8">
                    <CourseFilters 
                        courses={courses}
                        categories={categories}
                        schedules={schedules}
                        searchQuery={searchQuery}
                        onSearchChange={setSearchQuery}
                        categoryFilter={categoryFilter}
                        onCategoryChange={(v) => {setCategoryFilter(v); setCourseFilter('all'); setScheduleFilter('all');}}
                        courseFilter={courseFilter}
                        onCourseChange={(v) => {setCourseFilter(v); setScheduleFilter('all');}}
                        scheduleFilter={scheduleFilter}
                        onScheduleChange={setScheduleFilter}
                        dateRange={dateRange as any}
                        onDateRangeChange={(v) => setDateRange(v as any)}
                    />
                </CardHeader>

                <Tabs value={activeTab} onValueChange={v => setActiveTab(v as RegistrationStatus)} className="w-full">
                    <div className="px-8 pt-8">
                        <TabsList className="grid w-full grid-cols-3 h-16 rounded-[1.5rem] bg-slate-100/50 p-1.5 dark:bg-slate-900 border border-slate-200/50">
                            <TabsTrigger value="pending" className="rounded-xl font-bold">รอดำเนินการ</TabsTrigger>
                            <TabsTrigger value="confirmed" className="rounded-xl font-bold">ยืนยันแล้ว</TabsTrigger>
                            <TabsTrigger value="cancelled" className="rounded-xl font-bold">ยกเลิก</TabsTrigger>
                        </TabsList>
                    </div>

                    <div className="p-0 mt-8">
                        <div className="overflow-x-auto">
                            <Table className="min-w-[1100px]">
                                <TableHeader className="bg-slate-50/50 dark:bg-slate-900/30 border-y">
                                    <TableRow className="hover:bg-transparent">
                                        <TableHead className="py-5 pl-10 uppercase tracking-widest text-[10px] text-slate-400 font-bold">บริษัท / ผู้สมัคร</TableHead>
                                        <TableHead className="uppercase tracking-widest text-[10px] text-slate-400 font-bold">หลักสูตร / รอบอบรม</TableHead>
                                        <TableHead className="text-center uppercase tracking-widest text-[10px] text-slate-400 font-bold">ผู้อบรม</TableHead>
                                        <TableHead className="uppercase tracking-widest text-[10px] text-slate-400 font-bold">เอกสารการเงิน</TableHead>
                                        <TableHead className="text-right pr-10 uppercase tracking-widest text-[10px] text-slate-400 font-bold">ดำเนินการ</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {isLoading ? (
                                        <TableRow><TableCell colSpan={5} className="h-80 text-center"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary opacity-50"/></TableCell></TableRow>
                                    ) : filteredRegistrations.length > 0 ? filteredRegistrations.map(reg => {
                                        const isProcessing = processingId === reg.id;
                                        const schedule = schedulesMap.get(reg.scheduleId);
                                        return (
                                            <TableRow key={reg.id} className="group hover:bg-slate-50/50 transition-all border-b last:border-none">
                                                <TableCell className="py-8 pl-10 text-left">
                                                    <div className="font-semibold text-lg text-slate-900 dark:text-white">{reg.clientCompanyName || 'บุคคลทั่วไป'}</div>
                                                    <div className="text-xs text-muted-foreground">{reg.userDisplayName}</div>
                                                </TableCell>
                                                <TableCell className="text-left">
                                                    <div className="font-semibold text-sm">{coursesMap.get(reg.courseId)?.shortName || reg.courseTitle}</div>
                                                    <div className="text-[10px] text-primary font-bold uppercase tracking-widest mt-1">
                                                        {schedule ? format(new Date(schedule.startDate), 'd MMM yy', {locale: th}) : 'N/A'}
                                                    </div>
                                                </TableCell>
                                                <TableCell className="text-center">
                                                    <Badge variant="secondary" className="bg-blue-50 text-blue-700 font-bold">{Object.values(reg.formData).find(v => Array.isArray(v))?.length || 0} ท่าน</Badge>
                                                </TableCell>
                                                <TableCell className="text-left">
                                                    <div className="flex flex-col gap-1">
                                                        <Badge variant={reg.quotationGenerated ? "default" : "outline"} className="text-[9px] uppercase">QUOTATION</Badge>
                                                        <Badge variant={reg.invoiceGenerated ? "default" : "outline"} className="text-[9px] uppercase">INVOICE</Badge>
                                                    </div>
                                                </TableCell>
                                                <TableCell className="text-right pr-10">
                                                    <div className="flex justify-end gap-2">
                                                        <Button variant="outline" size="sm" onClick={() => setViewingRegistration(reg)} className="rounded-xl h-10"><Info className="w-4 h-4 mr-2"/> ข้อมูล</Button>
                                                        <Button variant="outline" size="sm" onClick={() => setManagingRegistration(reg)} className="rounded-xl h-10"><UserCheck className="w-4 h-4 mr-2"/> ผู้อบรม</Button>
                                                        <DropdownMenu>
                                                            <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="rounded-full h-10 w-10"><MoreHorizontal className="h-5 w-5"/></Button></DropdownMenuTrigger>
                                                            <DropdownMenuContent align="end" className="rounded-2xl w-56 p-2">
                                                                <DropdownMenuItem onClick={() => setReschedulingRegistration(reg)} className="rounded-xl py-2.5 font-semibold"><History className="mr-2 h-4 w-4"/> เลื่อนรอบ</DropdownMenuItem>
                                                                <DropdownMenuItem asChild className="rounded-xl py-2.5"><Link href={`/erp/registrations/edit/${reg.id}`} className="font-semibold"><Edit className="mr-2 h-4 w-4"/> แก้ไขใบสมัคร</Link></DropdownMenuItem>
                                                                <DropdownMenuSeparator />
                                                                <DropdownMenuItem onClick={() => handleAction(createQuotationAction, reg.id)} disabled={isProcessing} className="rounded-xl py-2.5 font-semibold"><FileText className="mr-2 h-4 w-4"/> ออกใบเสนอราคา</DropdownMenuItem>
                                                                <DropdownMenuItem onClick={() => handleAction(createInvoiceAction, reg.id)} disabled={isProcessing} className="rounded-xl py-2.5 font-semibold"><FileSignature className="mr-2 h-4 w-4"/> ออกใบแจ้งหนี้</DropdownMenuItem>
                                                                <DropdownMenuSeparator />
                                                                <DropdownMenuItem className="text-destructive font-semibold rounded-xl py-2.5" onClick={() => setRegistrationToDelete(reg)} disabled={isProcessing}><Trash2 className="mr-2 h-4 w-4"/> ลบใบสมัคร</DropdownMenuItem>
                                                            </DropdownMenuContent>
                                                        </DropdownMenu>
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        );
                                    }) : (
                                        <TableRow><TableCell colSpan={5} className="h-80 text-center italic font-light opacity-50">ไม่พบรายการ</TableCell></TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                </Tabs>
            </Card>

            <RegistrationDetailsDialog isOpen={!!viewingRegistration} onClose={() => setViewingRegistration(null)} registration={viewingRegistration} />
            <ManageAttendeesDialog isOpen={!!managingRegistration} onClose={() => setManagingRegistration(null)} registration={managingRegistration} onStateSave={() => {}} onRescheduleClick={(ids) => { setRescheduleAttendeeIds(ids); setReschedulingRegistration(managingRegistration); }} />
            <RescheduleDialog isOpen={!!reschedulingRegistration} onClose={() => { setReschedulingRegistration(null); setRescheduleAttendeeIds([]); }} registration={reschedulingRegistration} attendeeIds={rescheduleAttendeeIds} schedules={schedules} onSuccess={() => {}} />
            
            <AlertDialog open={!!registrationToDelete} onOpenChange={v => !v && setRegistrationToDelete(null)}>
                <AlertDialogContent className="rounded-[2.5rem] shadow-2xl border-none">
                    <AlertDialogHeader>
                        <AlertDialogTitle className="text-2xl font-bold font-headline text-slate-900 dark:text-white">ยืนยันการลบใบสมัคร?</AlertDialogTitle>
                        <AlertDialogDescription>การกระทำนี้ไม่สามารถย้อนกลับได้ ข้อมูลผู้อบรมในใบสมัครนี้จะถูกลบทั้งหมด</AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter className="gap-3 mt-6">
                        <AlertDialogCancel className="rounded-xl border-none bg-slate-100 hover:bg-slate-200 h-12 font-bold px-6">ยกเลิก</AlertDialogCancel>
                        <AlertDialogAction onClick={() => registrationToDelete && handleAction(deleteRegistration, registrationToDelete.id)} className="bg-destructive hover:bg-destructive/90 rounded-xl h-12 font-bold px-8">ลบข้อมูลทันที</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}