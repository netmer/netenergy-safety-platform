'use client';

import React, { useState } from 'react';
import Link from 'next/navigation';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/context/auth-context';
import { AdminLogin } from '@/components/auth/admin-login';
import {
  LayoutDashboard,
  BookOpen,
  Building,
  Newspaper,
  Loader2,
  ShieldAlert,
  FileText,
  Shield,
  Globe,
  Menu,
  Users,
  UserCircle,
  Award,
  BarChart3,
  Settings,
  ChevronRight,
  FileSignature,
  Network,
  TestTube2
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { UserAuthNav } from '@/components/auth/user-auth-nav';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { Sheet, SheetTrigger, SheetContent } from '@/components/ui/sheet';
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarToggle,
  SidebarHeader,
  SidebarGroup
} from '@/components/ui/sidebar';

const adminNavGroups = [
  {
    label: "Overview",
    items: [
      { href: '/admin', label: 'Dashboard', Icon: LayoutDashboard },
      { href: '/admin/analytics', label: 'Analytics', Icon: BarChart3 },
    ]
  },
  {
    label: "Management",
    items: [
      { href: '/admin/courses', label: 'จัดการหลักสูตร', Icon: BookOpen },
      { href: '/admin/users', label: 'จัดการผู้ใช้', Icon: Users },
      { href: '/admin/instructors', label: 'จัดการวิทยากร', Icon: UserCircle },
    ]
  },
  {
    label: "Tools & Website",
    items: [
      { href: '/admin/forms', label: 'จัดการแบบฟอร์ม', Icon: FileText },
      { href: '/admin/templates', label: 'จัดการแม่แบบใบเซอร์', Icon: FileSignature },
      { href: '/admin/certifications', label: 'ใบรับรองศูนย์', Icon: Award },
      { href: '/admin/clients', label: 'จัดการลูกค้าองค์กร', Icon: Building },
      { href: '/admin/content', label: 'จัดการเนื้อหาเว็บ', Icon: Newspaper },
    ]
  }
];

export default function AdminLayout({ children }: React.PropsWithChildren) {
  const { user, profile, loading } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const pathname = usePathname();

  if (loading) return <div className="flex h-svh w-full items-center justify-center bg-background"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>;
  if (!user) return <AdminLogin />;
  if (profile?.role !== 'admin') return <div className="flex min-h-svh items-center justify-center p-4"><Card className="w-full max-w-md text-center p-10 rounded-[2rem] border-none shadow-2xl"><ShieldAlert className="w-16 h-16 mx-auto text-destructive mb-6"/><h2 className="text-2xl font-bold font-headline mb-4">Access Denied</h2><p className="text-muted-foreground font-light mb-8">หน้านี้สำหรับผู้ดูแลระบบเท่านั้นครับ</p><Button asChild className="rounded-xl h-12 px-8 font-bold"><Link href="/">กลับหน้าหลัก</Link></Button></Card></div>;
  
  return (
    <SidebarProvider isCollapsed={isCollapsed}>
      <div className="relative flex min-h-screen w-full bg-slate-50 dark:bg-slate-950/20">
        <Sidebar>
            <SidebarHeader>
                <div className="flex items-center gap-3 font-bold px-2">
                    <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white shadow-lg shadow-primary/30"><Settings className="w-5 h-5" /></div>
                    {!isCollapsed && <span className="text-lg font-headline">Admin<span className="text-primary">Panel</span></span>}
                </div>
            </SidebarHeader>
            <SidebarContent>
                {adminNavGroups.map((group) => (
                    <SidebarGroup key={group.label} label={group.label}>
                        <SidebarMenu>
                            {group.items.map((item) => (
                                <SidebarMenuItem key={item.href}>
                                    <Link href={item.href}>
                                        <SidebarMenuButton Icon={item.Icon} isActive={pathname === item.href || (item.href !== '/admin' && pathname.startsWith(item.href))}>
                                            {item.label}
                                        </SidebarMenuButton>
                                    </Link>
                                </SidebarMenuItem>
                            ))}
                        </SidebarMenu>
                    </SidebarGroup>
                ))}
                <SidebarGroup label="Other Systems">
                    <SidebarMenu>
                        <SidebarMenuItem><Link href="/erp"><SidebarMenuButton Icon={Shield} className="bg-primary/5 text-primary">ERP Dashboard</SidebarMenuButton></Link></SidebarMenuItem>
                    </SidebarMenu>
                </SidebarGroup>
            </SidebarContent>
            <SidebarFooter>
                <div className="flex items-center justify-between">
                    {!isCollapsed && <Button asChild variant="ghost" size="sm" className="text-xs font-bold text-muted-foreground hover:text-primary"><Link href="/">Back to Site</Link></Button>}
                    <SidebarToggle onClick={() => setIsCollapsed(!isCollapsed)} />
                </div>
            </SidebarFooter>
        </Sidebar>

        <div className={cn("flex flex-col flex-1 transition-all duration-300", "md:ml-64", isCollapsed && "md:ml-[70px]")}>
          <header className="sticky top-0 z-30 flex h-16 items-center border-b bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl px-4 md:px-8">
            <div className="flex items-center gap-2 mr-auto md:hidden">
                <Sheet><SheetTrigger asChild><Button variant="ghost" size="icon" className="h-10 w-10 rounded-full"><Menu className="h-5 w-5" /></Button></SheetTrigger><SheetContent side="left" className="p-0"><div className="p-6 font-bold text-xl border-b font-headline">AdminPanel</div></SheetContent></Sheet>
            </div>
            <div className="hidden sm:flex items-center gap-2 text-sm font-medium text-muted-foreground">
                <span className="opacity-50">Admin</span><ChevronRight className="w-4 h-4 opacity-30" /><span className="text-foreground font-semibold">Website Management</span>
            </div>
            <div className="flex items-center gap-3"><ThemeToggle /><div className="h-6 w-px bg-border mx-1" /><UserAuthNav /></div>
          </header>
          <main className="flex-1 p-4 md:p-8 lg:p-10"><div className="max-w-[1600px] mx-auto">{children}</div></main>
        </div>
      </div>
    </SidebarProvider>
  );
}